"""Playwright async browser engine — session management, actions, evidence.

The engine is the only layer that touches Playwright directly.  Everything
above it (agents, verifier, analyst) works with the abstracted
:class:`~core.browser.dom_parser.DOMAbstraction` and plain dictionaries, so
the orchestration logic can be unit-tested without a live browser.

Responsibilities
----------------
* Launch / close a Chromium session (headless by default).
* Execute tool calls: ``click``, ``type``, ``select``, ``navigate``,
  ``hover``, ``assert_visible``, ``wait``, ``screenshot``.
* Capture *evidence* for every step: screenshot, console messages, network
  response codes, DOM snapshot, and (optionally) a Playwright trace zip.
* Adaptive timeouts driven by the Kalman latency tracker.
"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from core.algorithms.probabilistic import LatencyTracker
from core.browser.dom_parser import DOMAbstraction, from_accessibility_snapshot, parse_html

__all__ = ["StepRecord", "BrowserEngine", "BrowserActionError"]


class BrowserActionError(RuntimeError):
    """Raised when a browser tool call fails (missing element, timeout...)."""


@dataclass
class StepRecord:
    """Immutable evidence bundle for a single executed action."""

    index: int
    action: str
    target: str = ""
    ok: bool = True
    error: str = ""
    url_before: str = ""
    url_after: str = ""
    duration_ms: float = 0.0
    screenshot: Optional[str] = None
    console: List[str] = field(default_factory=list)
    network: List[Dict[str, Any]] = field(default_factory=list)
    dom_tokens: str = ""
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "index": self.index,
            "action": self.action,
            "target": self.target,
            "ok": self.ok,
            "error": self.error,
            "url_before": self.url_before,
            "url_after": self.url_after,
            "duration_ms": round(self.duration_ms, 2),
            "screenshot": self.screenshot,
            "console": self.console[-20:],
            "network": self.network[-20:],
            "dom_tokens": self.dom_tokens,
            "timestamp": self.timestamp,
        }


@dataclass
class BrowserEngine:
    """Async Playwright wrapper with evidence capture.

    Parameters
    ----------
    headless:
        Run Chromium without a visible window.
    artifacts_dir:
        Directory receiving screenshots and trace zips.
    record_trace:
        Start a Playwright tracing session (trace.zip = reproducible evidence).
    """

    headless: bool = True
    artifacts_dir: str = "artifacts"
    record_trace: bool = True
    default_timeout_ms: float = 5_000.0
    viewport: Dict[str, int] = field(default_factory=lambda: {"width": 1440, "height": 900})

    # ---- runtime state (set in start()) --------------------------------- #
    _playwright: Any = None
    _browser: Any = None
    _context: Any = None
    _page: Any = None
    _trace_started: bool = False
    _step_index: int = 0
    _console_log: List[str] = field(default_factory=list)
    _network_log: List[Dict[str, Any]] = field(default_factory=list)
    latency: LatencyTracker = field(default_factory=LatencyTracker)
    started: bool = False

    # ------------------------------------------------------------------ #
    # lifecycle
    # ------------------------------------------------------------------ #
    async def start(self) -> "BrowserEngine":
        """Launch Chromium and attach console/network listeners."""
        from playwright.async_api import async_playwright

        Path(self.artifacts_dir).mkdir(parents=True, exist_ok=True)
        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(headless=self.headless)
        self._context = await self._browser.new_context(
            viewport=self.viewport,
            record_video_dir=None,
        )
        if self.record_trace:
            await self._context.tracing.start(screenshots=True, snapshots=True, sources=True)
            self._trace_started = True
        self._page = await self._context.new_page()
        self._page.set_default_timeout(self.default_timeout_ms)
        self._console_log = []
        self._network_log = []

        self._page.on("console", self._on_console)
        self._page.on("response", self._on_response)
        self._page.on("pageerror", self._on_page_error)

        self.started = True
        return self

    def _on_console(self, msg: Any) -> None:
        try:
            self._console_log.append(f"[{msg.type}] {msg.text}")
        except Exception:  # pragma: no cover - defensive
            pass

    def _on_page_error(self, err: Any) -> None:
        self._console_log.append(f"[pageerror] {err}")

    async def _on_response(self, response: Any) -> None:
        try:
            self._network_log.append(
                {
                    "url": response.url,
                    "status": response.status,
                    "method": response.request.method,
                }
            )
        except Exception:  # pragma: no cover - defensive
            pass

    async def stop(self, keep_trace: bool = True) -> Optional[str]:
        """Close the session, exporting the trace if one was recorded."""
        trace_path: Optional[str] = None
        try:
            if self._trace_started and self._context is not None and keep_trace:
                trace_path = str(
                    Path(self.artifacts_dir) / f"trace-{uuid.uuid4().hex[:8]}.zip"
                )
                await self._context.tracing.stop(path=trace_path)
                self._trace_started = False
        except Exception:  # pragma: no cover - defensive
            trace_path = None
        for closer in (self._context, self._browser):
            try:
                if closer is not None:
                    await closer.close()
            except Exception:  # pragma: no cover - defensive
                pass
        if self._playwright is not None:
            try:
                await self._playwright.stop()
            except Exception:  # pragma: no cover - defensive
                pass
        self.started = False
        return trace_path

    # ------------------------------------------------------------------ #
    # introspection
    # ------------------------------------------------------------------ #
    @property
    def page(self) -> Any:
        if self._page is None:
            raise BrowserActionError("engine not started — call start() first")
        return self._page

    @property
    def console_messages(self) -> List[str]:
        return list(self._console_log)

    @property
    def network_messages(self) -> List[Dict[str, Any]]:
        return list(self._network_log)

    async def current_url(self) -> str:
        return self.page.url

    async def snapshot(self) -> DOMAbstraction:
        """DOM abstraction of the current page state.

        Tries the accessibility tree first and falls back to raw HTML.
        """
        try:
            snap = await self.page.accessibility.snapshot()
            if snap:
                abstraction = from_accessibility_snapshot(snap, url=self.page.url)
                if abstraction.nodes:
                    return abstraction
        except Exception:
            pass
        html = await self.page.content()
        return parse_html(html, url=self.page.url)

    async def screenshot(self, name: Optional[str] = None) -> str:
        """Save a full-page screenshot and return its path."""
        Path(self.artifacts_dir).mkdir(parents=True, exist_ok=True)
        filename = name or f"step-{self._step_index:03d}-{uuid.uuid4().hex[:6]}.png"
        path = str(Path(self.artifacts_dir) / filename)
        await self.page.screenshot(path=path, full_page=True)
        return path

    # ------------------------------------------------------------------ #
    # tool-call dispatch
    # ------------------------------------------------------------------ #
    async def execute(
        self,
        action: str,
        *,
        selector: str = "",
        ref: str = "",
        value: str = "",
        url: str = "",
        timeout_ms: Optional[float] = None,
        capture: bool = True,
        abstraction: Optional[DOMAbstraction] = None,
    ) -> StepRecord:
        """Execute one browser tool call and package its evidence."""
        if not self.started:
            raise BrowserActionError("engine not started")
        self._step_index += 1
        url_before = self.page.url
        started = time.perf_counter()
        console_mark = len(self._console_log)
        network_mark = len(self._network_log)
        target = selector or ref or url

        css = selector or self._resolve_ref(ref, abstraction)
        timeout = timeout_ms or self.latency.recommended_timeout()
        ok, error = True, ""

        try:
            action = action.lower().strip()
            if action == "navigate":
                await self.page.goto(url or value, timeout=timeout, wait_until="domcontentloaded")
            elif action == "click":
                await self.page.click(css, timeout=timeout)
            elif action == "type":
                await self.page.fill(css, value, timeout=timeout)
            elif action == "select":
                await self.page.select_option(css, value, timeout=timeout)
            elif action == "hover":
                await self.page.hover(css, timeout=timeout)
            elif action == "assert_visible":
                locator = self.page.locator(css)
                if not await locator.first.is_visible(timeout=timeout):
                    raise BrowserActionError(f"element not visible: {css}")
            elif action == "wait":
                await self.page.wait_for_timeout(int(float(value or 250)))
            elif action == "press":
                await self.page.press(css or "body", value or "Enter", timeout=timeout)
            elif action == "screenshot":
                pass  # handled by capture below
            else:
                raise BrowserActionError(f"unknown action: {action!r}")
        except Exception as exc:  # noqa: BLE001 - surfaced as step evidence
            ok, error = False, str(exc).split("\n")[0][:400]

        elapsed = (time.perf_counter() - started) * 1000.0
        self.latency.observe(elapsed)

        record = StepRecord(
            index=self._step_index,
            action=action,
            target=target,
            ok=ok,
            error=error,
            url_before=url_before,
            url_after=self.page.url,
            duration_ms=elapsed,
            console=self._console_log[console_mark:],
            network=self._network_log[network_mark:],
        )

        if capture:
            try:
                record.screenshot = await self.screenshot()
                abstraction = abstraction or await self.snapshot()
                record.dom_tokens = abstraction.to_tokens()
            except Exception as exc:  # pragma: no cover - evidence is best effort
                record.error = record.error or f"evidence capture failed: {exc}"

        return record

    @staticmethod
    def _resolve_ref(ref: str, abstraction: Optional[DOMAbstraction]) -> str:
        if not ref:
            return ""
        if abstraction is None:
            raise BrowserActionError(
                f"cannot resolve reference {ref!r} without a DOM abstraction"
            )
        node = abstraction.by_ref(ref)
        return node.selector

    # ------------------------------------------------------------------ #
    # convenience wrappers used by the agents
    # ------------------------------------------------------------------ #
    async def goto(self, url: str) -> StepRecord:
        return await self.execute("navigate", url=url)

    async def text_of_body(self) -> str:
        try:
            return (await self.page.inner_text("body"))[:4000]
        except Exception:
            return ""
