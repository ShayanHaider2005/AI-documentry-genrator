"""Browser Agent — the execution loop that drives Playwright.

The agent walks the Planner's DAG, resolving intent-based steps against the
*abstracted* DOM (never raw HTML), executing tool calls through
:class:`~core.browser.engine.BrowserEngine`, and shipping every step to the
Verifier for dual DOM + vision confirmation.

Recovery loop
-------------
1. Resolve the step target (CSS selector → DOM reference → text match).
2. Capture the *before* state (screenshot + interactive abstraction).
3. Execute the tool call.
4. Verify the *after* state with the Verifier Agent.
5. On failure, ask the optional LLM policy for a corrective action
   (alternative selector, wait-and-retry) — up to ``max_retries`` times —
   otherwise fall back to a deterministic recovery ladder.
6. Record step evidence + estimated token cost.

Everything is awaitable and fully typed; the deterministic policy makes the
whole loop reproducible offline (used by the test-suite).
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, List, Optional, Sequence

from core.agents.planner import PlanStep, PlannerAgent, TestPlan
from core.agents.verifier import VerificationResult, VerifierAgent
from core.browser.dom_parser import DOMAbstraction, InteractiveNode
from core.browser.engine import BrowserEngine, StepRecord

__all__ = ["BrowserAgent", "RunOutcome", "AgentDecision", "LLMPolicy"]

# Optional LLM tool-calling policy: context -> structured decision.
LLMPolicy = Callable[[Dict[str, Any]], Awaitable[Dict[str, Any]]]

# Structural tags a degraded selector may fall back to (see ``_recover_selector``).
_KNOWN_TAGS = frozenset({
    "a", "button", "input", "select", "textarea", "form", "table", "h1", "h2",
    "h3", "h4", "p", "span", "div", "label", "img", "ul", "li", "nav",
    "header", "footer", "section", "main", "tr", "td", "th",
})

_ATTR_SELECTOR = re.compile(
    r"^(?P<tag>[a-zA-Z][\w-]*)?\s*\[\s*(?P<attr>[\w-]+)\s*=\s*"
    r"(?P<val>[^\]'\"]+?)\s*\]$"
)


def selector_present(target: str, abstraction: DOMAbstraction) -> bool:
    """Whether an explicit CSS selector still resolves in the live DOM.

    The Planner writes selectors against the *canonical* markup; the target
    application can churn ``id``/``class`` attributes on every render
    (BUG_3), at which point the literal selector no longer matches anything
    even though the element itself is still there.
    """
    if target in {"body", "html"}:
        return True
    if not abstraction.nodes and not abstraction.all_ids:
        return True  # no usable evidence → keep the selector as written

    nodes = abstraction.nodes
    if target.startswith("#"):
        ident = target[1:].split("[", 1)[0].split(".", 1)[0]
        if ident in set(abstraction.all_ids):
            return True
        return any((n.attributes.get("id") or "") == ident for n in nodes)
    if target.startswith("."):
        cls = target[1:].split("[", 1)[0].split(".", 1)[0]
        return any(cls in (n.attributes.get("class") or "").split() for n in nodes)
    match = _ATTR_SELECTOR.match(target)
    if match:
        tag = (match.group("tag") or "").lower()
        attr, value = match.group("attr"), match.group("val")
        for node in nodes:
            if tag and node.tag != tag:
                continue
            if (node.attributes.get(attr) or "") == value:
                return True
        return False
    if any(n.tag == target.lower() for n in nodes):
        return True
    return True  # combinators / pseudo-classes: not worth second-guessing


def recover_selector(target: str, abstraction: DOMAbstraction) -> Optional[str]:
    """Find the element a vanished ``#id`` / ``.class`` used to point at.

    Relies on attributes the target application keeps *stable* while the
    volatile ones churn: the ``name`` attribute of form controls, the id
    prefix (``reset-link-a1b2c3`` still starts with ``reset-link``) and, as a
    last resort, the element's tag encoded in the class token itself
    (``orders-table`` → ``table``).
    """
    ident = re.split(r"[.[:]", target.lstrip("#."), 1)[0]
    if not ident:
        return None
    needle = ident.lower()

    for node in abstraction.nodes:
        if (node.attributes.get("name") or "").lower() == needle:
            return node.selector
    for node in abstraction.nodes:
        node_id = (node.attributes.get("id") or "").lower()
        if node_id and (node_id == needle or node_id.startswith(needle + "-")):
            return node.selector
    for node in abstraction.nodes:
        if needle in f"{node.name} {node.text}".lower():
            return node.selector
    for tag in sorted(_KNOWN_TAGS, key=len, reverse=True):
        if needle == tag or needle.endswith("-" + tag) or needle.startswith(tag + "-"):
            if any(n.tag == tag for n in abstraction.nodes):
                return tag
    return None


@dataclass
class AgentDecision:
    """Structured LLM (or heuristic) response for one decision point."""

    action: str = ""
    target: str = ""
    value: str = ""
    reason: str = ""
    confidence: float = 0.0
    source: str = "heuristic"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "action": self.action,
            "target": self.target,
            "value": self.value,
            "reason": self.reason,
            "confidence": round(self.confidence, 3),
            "source": self.source,
        }


@dataclass
class RunOutcome:
    """Everything the orchestrator needs to persist / display."""

    goal: str
    plan: TestPlan
    steps: List[StepRecord] = field(default_factory=list)
    verifications: List[VerificationResult] = field(default_factory=list)
    decisions: List[AgentDecision] = field(default_factory=list)
    goal_reached: bool = False
    completed_steps: int = 0
    total_steps: int = 0
    tokens_estimated: int = 0
    duration_ms: float = 0.0
    trace_path: Optional[str] = None
    error: str = ""

    @property
    def passed(self) -> bool:
        """A run passes only if it reached its goal *and* found nothing wrong."""
        return self.goal_reached and not self.error and not self.anomalies

    @property
    def task_completion_rate(self) -> float:
        if not self.total_steps:
            return 0.0
        return self.completed_steps / self.total_steps

    @property
    def anomalies(self) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        for verification in self.verifications:
            for anomaly in verification.anomalies:
                out.append({"step": verification.step_index, **anomaly.to_dict()})
        return out

    def to_dict(self) -> Dict[str, Any]:
        return {
            "goal": self.goal,
            "passed": self.passed,
            "goal_reached": self.goal_reached,
            "plan": self.plan.to_dict(),
            "completed_steps": self.completed_steps,
            "total_steps": self.total_steps,
            "task_completion_rate": round(self.task_completion_rate, 4),
            "tokens_estimated": self.tokens_estimated,
            "duration_ms": round(self.duration_ms, 2),
            "trace_path": self.trace_path,
            "error": self.error,
            "steps": [s.to_dict() for s in self.steps],
            "verifications": [v.to_dict() for v in self.verifications],
            "decisions": [d.to_dict() for d in self.decisions],
            "anomalies": self.anomalies,
        }


@dataclass
class BrowserAgent:
    """Autonomous execution loop bound to a Playwright engine."""

    engine: BrowserEngine
    planner: PlannerAgent
    verifier: VerifierAgent
    llm: Optional[LLMPolicy] = None
    max_steps: int = 40
    max_retries: int = 2
    verbose: bool = False

    # ------------------------------------------------------------------ #
    # target resolution
    # ------------------------------------------------------------------ #
    @staticmethod
    def resolve_target(step: PlanStep, abstraction: DOMAbstraction) -> str:
        """Map a plan target onto a concrete Playwright selector.

        Resolution ladder:
          1. explicit CSS (``#id``, ``.class``, ``tag[...]``) — *only when it
             still exists in the live DOM*; otherwise the element is recovered
             by its stable attributes before falling through.
          2. DOM reference (``e12``)
          3. text / accessible-name match inside the abstraction
          4. the raw target string (Playwright accepts ``text=`` and
             ``:has-text()`` pseudo-selectors natively)
        """
        target = (step.target or "").strip()
        if not target:
            return "body"
        if target.startswith("#") or target.startswith(".") or "[" in target or target == "body":
            if target == "body" or selector_present(target, abstraction):
                return target
            # BUG_3 style drift: the selector is gone but the element is not.
            return recover_selector(target, abstraction) or target
        if target.startswith("e") and target[1:].isdigit():
            try:
                return abstraction.by_ref(target).selector
            except KeyError:
                pass

        lowered = target.lower()
        css_tokens = r"#.[\]:()=+~>,"
        known_tags = {
            "a", "button", "input", "select", "textarea", "form", "table",
            "h1", "h2", "h3", "h4", "p", "span", "div", "label", "img",
            "ul", "li", "body", "html", "nav", "header", "footer",
            "section", "main", "tr", "td", "th",
        }
        # Genuine CSS (contains selector punctuation or is a bare tag name).
        if any(c in target for c in css_tokens) or lowered in known_tags:
            return target
        if lowered.startswith("link ") or lowered.startswith("button "):
            label = target.split(" ", 1)[1].strip().strip('"').strip("'")
            engine = "a" if lowered.startswith("link") else "button"
            return f"{engine}:has-text('{label}')"

        # Text match: exact, then substring, then word overlap.
        candidates: List[InteractiveNode] = list(abstraction.nodes)
        for node in candidates:
            if node.name.lower() == lowered or node.text.lower() == lowered:
                return node.selector
        for node in candidates:
            if lowered in (node.name + " " + node.text).lower():
                return node.selector
        words = set(lowered.split())
        best, best_score = None, 0.0
        for node in candidates:
            blob = f"{node.name} {node.text}".lower()
            score = sum(1 for w in words if w in blob) / max(1, len(words))
            if score > best_score:
                best, best_score = node, score
        if best is not None and best_score >= 0.5:
            return best.selector

        # Fall back to Playwright's text engine, then to the page body for
        # visibility assertions (a page-level check still has meaning).
        if getattr(step, "action", "") == "assert_visible":
            return "body"
        if lowered.startswith("link "):
            return f"a:has-text('{target[5:].strip().strip(chr(34))}')"
        if lowered.startswith("button "):
            return f"button:has-text('{target[7:].strip().strip(chr(34))}')"
        return target

    # ------------------------------------------------------------------ #
    # corrective policy
    # ------------------------------------------------------------------ #
    async def _corrective_decision(
        self,
        step: PlanStep,
        verification: VerificationResult,
        abstraction: DOMAbstraction,
        attempt: int,
    ) -> AgentDecision:
        """LLM-first recovery, deterministic ladder as fallback."""
        context = {
            "intent": step.intent,
            "action": step.action,
            "target": step.target,
            "verification": verification.to_dict(),
            "attempt": attempt,
            "dom": abstraction.to_tokens(),
        }
        if self.llm is not None:
            try:
                raw = await self.llm(context)
                decision = AgentDecision(
                    action=str(raw.get("action", step.action)),
                    target=str(raw.get("target", step.target)),
                    value=str(raw.get("value", step.value)),
                    reason=str(raw.get("reason", "llm recovery")),
                    confidence=float(raw.get("confidence", 0.6)),
                    source="llm",
                )
                if decision.action:
                    return decision
            except Exception as exc:  # noqa: BLE001 - offline fallback
                if self.verbose:
                    print(f"[browser] LLM policy failed ({exc}); using heuristic")

        # Deterministic recovery ladder.
        kinds = set(verification.anomaly_kinds)
        # An explicit selector missing from the live DOM is a resolution
        # problem, not a timing one: re-resolve against the fresh abstraction
        # first, and stop burning retry budget when nothing can be recovered
        # (a fresh snapshot is taken *after* load, so "absent" here is real).
        if step.target and not selector_present(step.target, abstraction):
            fresh = self.resolve_target(step, abstraction) or step.target
            if fresh != step.target:
                return AgentDecision(
                    action=step.action, target=fresh, value=step.value,
                    reason="selector absent from live DOM: re-resolved",
                    confidence=0.6, source="heuristic",
                )
            return AgentDecision(
                action="", target=step.target, value=step.value,
                reason="selector absent from live DOM and unrecoverable",
                confidence=0.9, source="heuristic",
            )
        if "LATENCY_FLAKINESS" in kinds or not step.target:
            return AgentDecision(action="wait", value="750",
                                 reason="wait for dynamic UI before retrying",
                                 confidence=0.7, source="heuristic")
        if "SELECTOR_RESILIENCE" in kinds:
            # Re-resolve against the *fresh* abstraction (ids may have moved).
            fresh = self.resolve_target(step, abstraction)
            return AgentDecision(action=step.action, target=fresh,
                                 value=step.value,
                                 reason="selector drift: re-resolved from live DOM",
                                 confidence=0.6, source="heuristic")
        if attempt == 0:
            return AgentDecision(action=step.action, target=step.target,
                                 value=step.value,
                                 reason="transient failure: immediate retry",
                                 confidence=0.5, source="heuristic")
        return AgentDecision(action="", reason="no recovery available",
                             confidence=0.0, source="heuristic")

    # ------------------------------------------------------------------ #
    # main loop
    # ------------------------------------------------------------------ #
    async def run(
        self,
        goal: str,
        *,
        start_state: str = "/",
        algorithm: str = "astar",
        collect_evidence: bool = True,
    ) -> RunOutcome:
        """Execute the full plan for ``goal`` and return a :class:`RunOutcome`."""
        started = time.perf_counter()
        plan = self.planner.plan(goal, start_state=start_state, algorithm=algorithm)
        ordered = plan.topological_order()
        outcome = RunOutcome(
            goal=goal, plan=plan, total_steps=min(len(ordered), self.max_steps)
        )

        if not self.engine.started:
            await self.engine.start()

        # Seed the session at the application root.
        root = plan.target_url.rstrip("/") + "/"
        await self.engine.goto(root)

        goal_path = _path_of(plan.goal_state)
        executed = 0
        # Some goals legitimately *leave* their goal state again — a password
        # reset ends on ``/login?reset=1`` and then signs in, moving on to
        # ``/profile``.  Track whether the goal state was ever observed so the
        # final assertion rewards the flow that actually reached it instead of
        # only where it happened to stop.
        goal_seen = _url_matches(root, plan.goal_state)

        for step in ordered[: self.max_steps]:
            if executed >= self.max_steps:
                break
            before_shot = await self._safe_screenshot()
            before_abs = await self._safe_snapshot()
            selector = self.resolve_target(step, before_abs)

            record: Optional[StepRecord] = None
            verification: Optional[VerificationResult] = None
            last_decision = AgentDecision(
                action=step.action, target=selector, value=step.value,
                reason=f"plan step {step.id}: {step.intent}", source="plan",
            )

            for attempt in range(self.max_retries + 1):
                record = await self.engine.execute(
                    step.action,
                    selector=selector if step.action != "navigate" else "",
                    url=step.target if step.action == "navigate" else "",
                    value=last_decision.value or step.value,
                    abstraction=before_abs,
                )
                after_abs = await self._safe_snapshot()
                after_shot = await self._safe_screenshot()

                verification = self.verifier.verify_step(
                    record,
                    before_screenshot=before_shot,
                    after_screenshot=after_shot,
                    before_abstraction=before_abs,
                    after_abstraction=after_abs,
                    expectation=step.verification,
                )
                outcome.steps.append(record)
                outcome.verifications.append(verification)
                outcome.tokens_estimated += after_abs.token_estimate()
                outcome.decisions.append(last_decision)

                if verification.passed or attempt == self.max_retries:
                    break

                decision = await self._corrective_decision(
                    step, verification, after_abs, attempt
                )
                if not decision.action:
                    break
                last_decision = decision
                selector = decision.target or selector
                before_abs, before_shot = after_abs, after_shot
                if self.verbose:
                    print(f"[browser] retry {attempt + 1}: {decision.reason}")

            executed += 1
            if record is not None and record.ok:
                outcome.completed_steps += 1
            if record is not None and _url_matches(record.url_after, plan.goal_state):
                goal_seen = True

            # Early exit: hard failure that recovery could not fix.
            if verification is not None and not verification.passed:
                fatal = {"API_FAILURE", "UI_STATE_FAILURE"} & set(
                    verification.anomaly_kinds
                )
                if fatal and record is not None and not record.ok:
                    outcome.error = record.error
                    break

        # ---- goal assertion -------------------------------------------- #
        current_url = await self.engine.current_url()
        outcome.goal_reached = goal_seen or _url_matches(current_url, plan.goal_state)
        if not outcome.goal_reached and not outcome.error:
            outcome.error = (
                f"goal state {plan.goal_state!r} not reached (current: {current_url})"
            )

        outcome.completed_steps = min(outcome.completed_steps, outcome.total_steps)
        outcome.duration_ms = (time.perf_counter() - started) * 1000.0
        outcome.trace_path = await self.engine.stop(keep_trace=True)
        return outcome

    # ------------------------------------------------------------------ #
    async def _safe_screenshot(self) -> Optional[bytes]:
        try:
            return await self.engine.page.screenshot(full_page=True)
        except Exception:  # pragma: no cover - best effort evidence
            return None

    async def _safe_snapshot(self) -> DOMAbstraction:
        try:
            return await self.engine.snapshot()
        except Exception:  # pragma: no cover
            return DOMAbstraction(nodes=[], source="unavailable")


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def _path_of(goal_state: str) -> str:
    """``/checkout#done`` → ``/checkout`` (fragment is a logical marker)."""
    return goal_state.split("#", 1)[0] or "/"


def _url_matches(url: str, goal_state: str) -> bool:
    """Match the live URL against the plan's goal state.

    Fragments (``#2``, ``#done``) are logical markers without a real
    browser counterpart, so they are ignored for the path comparison but
    checked through a soft keyword heuristic.
    """
    if not goal_state or goal_state == "/":
        return True
    path = _path_of(goal_state)
    from urllib.parse import urlparse

    parsed = urlparse(url)
    if path == "/":
        return True
    goal_path = path.rstrip("/") or "/"
    url_path = parsed.path.rstrip("/") or "/"
    if url_path == goal_path:
        return True
    # Deep links such as /checkout/step/2 satisfy the /checkout goal state.
    if url_path.startswith(goal_path + "/"):
        return True
    return False
