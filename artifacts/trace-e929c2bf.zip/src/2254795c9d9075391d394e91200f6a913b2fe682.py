"""End-to-end integration: Playwright agent against the embedded target app.

These tests boot the FastAPI target application in a background thread and
drive it with the real browser stack (Chromium via Playwright).  They are
marked ``integration`` and skipped automatically when no browser binary is
installed.
"""

from __future__ import annotations

import asyncio
import socket
import threading
import time
from typing import Iterator

import pytest

# --------------------------------------------------------------------------- #
# browser availability probe
# --------------------------------------------------------------------------- #
def _chromium_available() -> bool:
    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=True)
            browser.close()
        return True
    except Exception:  # noqa: BLE001 - any failure means "not usable"
        return False


HAS_BROWSER = _chromium_available()

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(not HAS_BROWSER, reason="Playwright Chromium not installed"),
]


# --------------------------------------------------------------------------- #
# server fixture
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="module")
def target_url() -> Iterator[str]:
    """Boot the target app on a free port and tear it down afterwards."""
    import uvicorn

    from target_app.app import app, BUGS, USERS

    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()

    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning")
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    base = f"http://127.0.0.1:{port}"
    deadline = time.time() + 20
    while time.time() < deadline:
        try:
            import httpx

            if httpx.get(f"{base}/health", timeout=1.0).status_code == 200:
                break
        except Exception:  # noqa: BLE001 - still booting
            time.sleep(0.2)
    else:  # pragma: no cover - boot failure
        pytest.fail("target application failed to start")

    # Fresh state for every integration module.
    USERS.clear()
    BUGS.bug_1_disabled_submit = False
    BUGS.bug_2_reset_api_failure = False
    BUGS.bug_3_selector_drift = False
    BUGS.bug_4_latency = False

    yield base

    server.should_exit = True
    thread.join(timeout=10)
    USERS.clear()


# --------------------------------------------------------------------------- #
# DOM abstraction against a live page
# --------------------------------------------------------------------------- #
class TestLiveDOM:
    @pytest.mark.asyncio
    async def test_snapshot_captures_interactive_nodes(self, target_url):
        from core.browser.engine import BrowserEngine

        engine = BrowserEngine(headless=True, record_trace=False,
                               artifacts_dir="artifacts")
        await engine.start()
        try:
            await engine.goto(f"{target_url}/login")
            abstraction = await engine.snapshot()
            assert abstraction.nodes, "live page must expose interactive nodes"
            tokens = abstraction.to_tokens()
            assert "[e1]" in tokens
            assert "email" in tokens.lower()
            refs = {node.ref for node in abstraction.nodes}
            assert "e1" in refs
        finally:
            await engine.stop(keep_trace=False)

    @pytest.mark.asyncio
    async def test_step_evidence_captured(self, target_url):
        from core.browser.engine import BrowserEngine

        engine = BrowserEngine(headless=True, record_trace=False,
                               artifacts_dir="artifacts")
        await engine.start()
        try:
            await engine.goto(f"{target_url}/login")
            record = await engine.execute("type", selector="#email",
                                          value="demo@browserpilot.test")
            assert record.ok
            assert record.screenshot and record.screenshot.endswith(".png")
            assert record.dom_tokens
            assert record.duration_ms > 0
        finally:
            await engine.stop(keep_trace=False)


# --------------------------------------------------------------------------- #
# Full agent loop
# --------------------------------------------------------------------------- #
class TestAgentRun:
    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_registration_flow_passes_when_clean(self, target_url):
        from core.agents.orchestrator import Orchestrator

        orchestrator = Orchestrator(base_url=target_url, headless=True,
                                    record_trace=True, artifacts_dir="artifacts")
        await orchestrator.reset_target()
        result = await orchestrator.run(
            "Test whether a new user can register an account",
            persist=False,
            set_bugs={},
        )
        summary = result["summary"]
        assert summary["status"] in {"passed", "failed"}
        assert summary["task_completion_rate"] > 0.5, summary
        assert result["outcome"]["steps"], "at least one step must be executed"
        # The planner must have produced a multi-step DAG.
        assert result["outcome"]["plan"]["steps"]

    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_bug_1_detected_when_injected(self, target_url):
        from core.agents.orchestrator import Orchestrator

        orchestrator = Orchestrator(base_url=target_url, headless=True,
                                    record_trace=False, artifacts_dir="artifacts")
        await orchestrator.reset_target()
        result = await orchestrator.run(
            "Test whether a new user can register an account",
            persist=False,
            set_bugs={"bug_1_disabled_submit": True},
        )
        await orchestrator._set_bugs({})   # restore

        bugs = result["bugs"]
        kinds = [
            anomaly["kind"]
            for anomaly in result["outcome"]["anomalies"]
        ]
        assert bugs or kinds, "an injected bug must be detected"
        if bugs:
            assert bugs[0]["severity"] in {"CRITICAL", "HIGH", "MEDIUM", "LOW"}
            assert bugs[0]["steps_to_reproduce"]

    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_verification_records_failures_for_bug_2(self, target_url):
        from core.agents.orchestrator import Orchestrator

        orchestrator = Orchestrator(base_url=target_url, headless=True,
                                    record_trace=False, artifacts_dir="artifacts")
        await orchestrator.reset_target()
        result = await orchestrator.run(
            "Test whether a user can reset their password",
            persist=False,
            set_bugs={"bug_2_reset_api_failure": True},
        )
        await orchestrator._set_bugs({})

        verifications = result["outcome"]["verifications"]
        assert verifications, "verifier must run for every step"
        failed = [v for v in verifications if not v["passed"]]
        # Either the reset link 500s (verification failure) or the analyst
        # classified the API error — both prove detection.
        assert failed or result["bugs"]


# --------------------------------------------------------------------------- #
# Backend API
# --------------------------------------------------------------------------- #
class TestBackendAPI:
    @pytest.mark.asyncio
    async def test_health_endpoint(self):
        from fastapi.testclient import TestClient

        from backend.main import app

        client = TestClient(app)
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json() == {"status": "ok"}

    @pytest.mark.asyncio
    async def test_metrics_endpoint_empty(self, tmp_path, monkeypatch):
        from fastapi.testclient import TestClient

        monkeypatch.setenv("BROWSERPILOT_DATABASE_URL",
                           f"sqlite:///{(tmp_path / 'api.db').as_posix()}")
        import core.database.session as db

        monkeypatch.setattr(db, "_ENGINE", None)
        monkeypatch.setattr(db, "_SESSION_FACTORY", None)

        from backend.main import app

        client = TestClient(app)
        response = client.get("/api/metrics")
        assert response.status_code == 200
        assert response.json()["runs"] == 0

    def test_run_validation_rejects_short_goal(self):
        from fastapi.testclient import TestClient

        from backend.main import app

        client = TestClient(app)
        response = client.post("/api/runs", json={"goal": "x"})
        assert response.status_code == 422

    def test_search_endpoint(self, tmp_path, monkeypatch):
        from fastapi.testclient import TestClient

        monkeypatch.setenv("BROWSERPILOT_DATABASE_URL",
                           f"sqlite:///{(tmp_path / 'search.db').as_posix()}")
        import core.database.session as db

        monkeypatch.setattr(db, "_ENGINE", None)
        monkeypatch.setattr(db, "_SESSION_FACTORY", None)

        from backend.main import app

        client = TestClient(app)
        assert client.get("/api/search").status_code == 200
