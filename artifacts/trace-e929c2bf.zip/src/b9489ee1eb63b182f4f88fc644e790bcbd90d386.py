"""Multi-agent orchestrator — plans, executes, verifies, analyses, persists.

This is the entry point used by both the FastAPI worker and the Streamlit
dashboard:

    orchestrator = Orchestrator(base_url="http://127.0.0.1:8080")
    result = await orchestrator.run("Test registration, login and profile edit")

Pipeline
--------
    goal ─▶ PlannerAgent (DAG + A*)
             └▶ BrowserAgent (Playwright loop)
                  └▶ VerifierAgent (DOM + vision + HMM)
                       └▶ BugAnalyst (severity / root cause / dedupe)
                            └▶ SQLite (runs, steps, bugs, traces, metrics)

A **benchmark** mode re-runs the same goal with a *fixed* Playwright script
(hard-coded selectors) to quantify what BrowserPilot buys you: task
completion rate, bug-detection precision, false-alarm rate, execution time
and token cost.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from core.agents.analyst import BugAnalyst, BugReport
from core.agents.browser_agent import BrowserAgent, RunOutcome
from core.agents.planner import PlannerAgent
from core.agents.verifier import VerifierAgent
from core.browser.engine import BrowserEngine
from core.database.models import AgentTrace, BugReport as BugRow, SearchMetric, Step, TestRun
from core.database.session import init_db, session_scope

__all__ = ["Orchestrator", "RunSummary"]


@dataclass
class RunSummary:
    run_id: Optional[int] = None
    goal: str = ""
    status: str = "pending"
    task_completion_rate: float = 0.0
    bugs_found: int = 0
    duration_ms: float = 0.0
    tokens_estimated: int = 0
    trace_path: Optional[str] = None
    error: str = ""
    bug_titles: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "goal": self.goal,
            "status": self.status,
            "task_completion_rate": round(self.task_completion_rate, 4),
            "bugs_found": self.bugs_found,
            "duration_ms": round(self.duration_ms, 2),
            "tokens_estimated": self.tokens_estimated,
            "trace_path": self.trace_path,
            "error": self.error,
            "bug_titles": self.bug_titles,
        }


@dataclass
class Orchestrator:
    """End-to-end autonomous testing pipeline."""

    base_url: str = "http://127.0.0.1:8080"
    headless: bool = True
    artifacts_dir: str = "artifacts"
    record_trace: bool = True
    algorithm: str = "astar"
    use_llm: bool = False
    verbose: bool = False
    llm_planner: Optional[Any] = None
    llm_policy: Optional[Any] = None
    vision_llm: Optional[Any] = None

    # constructed in __post_init__
    engine: BrowserEngine = field(init=False, default=None)  # type: ignore[assignment]
    planner: PlannerAgent = field(init=False, default=None)  # type: ignore[assignment]
    verifier: VerifierAgent = field(init=False, default=None)  # type: ignore[assignment]
    agent: BrowserAgent = field(init=False, default=None)  # type: ignore[assignment]
    analyst: BugAnalyst = field(init=False, default=None)  # type: ignore[assignment]

    def __post_init__(self) -> None:
        self.engine = BrowserEngine(
            headless=self.headless,
            artifacts_dir=self.artifacts_dir,
            record_trace=self.record_trace,
        )
        self.planner = PlannerAgent(
            base_url=self.base_url,
            llm=self.llm_planner if self.use_llm else None,
        )
        self.verifier = VerifierAgent(vision_llm=self.vision_llm, verbose=self.verbose)
        self.agent = BrowserAgent(
            engine=self.engine,
            planner=self.planner,
            verifier=self.verifier,
            llm=self.llm_policy if self.use_llm else None,
            verbose=self.verbose,
        )
        self.analyst = BugAnalyst()

    # ------------------------------------------------------------------ #
    # main entry point
    # ------------------------------------------------------------------ #
    async def run(
        self,
        goal: str,
        *,
        persist: bool = True,
        algorithm: Optional[str] = None,
        set_bugs: Optional[Dict[str, bool]] = None,
    ) -> Dict[str, Any]:
        """Execute one autonomous test session and persist the evidence."""
        init_db()
        if set_bugs is not None:
            await self._set_bugs(set_bugs)

        outcome = await self.agent.run(
            goal, algorithm=algorithm or self.algorithm
        )
        anomalies = outcome.anomalies
        reports: List[BugReport] = self.analyst.analyze(outcome, anomalies)

        summary = RunSummary(
            goal=goal,
            status="passed" if outcome.passed else "failed",
            task_completion_rate=outcome.task_completion_rate,
            bugs_found=len(reports),
            duration_ms=outcome.duration_ms,
            tokens_estimated=outcome.tokens_estimated,
            trace_path=outcome.trace_path,
            error=outcome.error,
            bug_titles=[r.title for r in reports],
        )

        if persist:
            summary.run_id = self._persist(outcome, reports, summary)
        return {"summary": summary.to_dict(), "outcome": outcome.to_dict(),
                "bugs": [r.to_dict() for r in reports]}

    def run_sync(self, goal: str, **kwargs: Any) -> Dict[str, Any]:
        """Blocking wrapper for callers that cannot await."""
        return asyncio.run(self.run(goal, **kwargs))

    # ------------------------------------------------------------------ #
    # persistence
    # ------------------------------------------------------------------ #
    def _persist(
        self,
        outcome: RunOutcome,
        reports: List[BugReport],
        summary: RunSummary,
    ) -> int:
        from datetime import datetime, timezone

        with session_scope() as session:
            run = TestRun(
                goal=outcome.goal,
                target_url=outcome.plan.target_url,
                status=summary.status,
                started_at=datetime.fromtimestamp(
                    outcome.plan.created_at, tz=timezone.utc
                ),
                finished_at=datetime.now(timezone.utc),
                duration_ms=outcome.duration_ms,
                steps_count=len(outcome.steps),
                bugs_found=len(reports),
                task_completion_rate=outcome.task_completion_rate,
                token_estimate=outcome.tokens_estimated,
                trace_path=outcome.trace_path,
                error=outcome.error or None,
                metrics={
                    "anomalies": outcome.anomalies,
                    "verifications": [v.to_dict() for v in outcome.verifications],
                    "decisions": [d.to_dict() for d in outcome.decisions],
                    "plan": outcome.plan.to_dict(),
                },
            )
            session.add(run)
            session.flush()

            for record in outcome.steps:
                session.add(
                    Step(
                        run_id=run.id,
                        index=record.index,
                        action=record.action,
                        target=record.target,
                        ok=1 if record.ok else 0,
                        error=record.error,
                        url_before=record.url_before,
                        url_after=record.url_after,
                        duration_ms=record.duration_ms,
                        screenshot=record.screenshot,
                        console=record.console,
                        network=record.network,
                        dom_tokens=record.dom_tokens[:20000],
                    )
                )

            for verification in outcome.verifications:
                session.add(
                    AgentTrace(
                        run_id=run.id,
                        agent="verifier",
                        level="info" if verification.passed else "warn",
                        message=(
                            f"step #{verification.step_index}: "
                            f"{'passed' if verification.passed else 'failed'} "
                            f"({len(verification.anomalies)} anomaly/anomalies)"
                        ),
                        payload=verification.to_dict(),
                    )
                )

            for decision in outcome.decisions:
                session.add(
                    AgentTrace(
                        run_id=run.id,
                        agent="browser",
                        level="decision",
                        message=decision.reason,
                        payload=decision.to_dict(),
                    )
                )

            session.add(
                AgentTrace(
                    run_id=run.id,
                    agent="planner",
                    level="decision",
                    message=(
                        f"plan {outcome.plan.plan_id} via "
                        f"{outcome.plan.search.algorithm if outcome.plan.search else 'n/a'}"
                    ),
                    payload=outcome.plan.to_dict(),
                )
            )

            for report in reports:
                session.add(
                    BugRow(
                        run_id=run.id,
                        title=report.title,
                        summary=report.summary,
                        severity=report.severity,
                        root_cause=report.root_cause,
                        category=report.category,
                        steps_to_reproduce=report.steps_to_reproduce,
                        evidence=report.evidence,
                        console_errors=report.console_errors,
                        screenshot=report.screenshot,
                        trace_path=report.trace_path,
                        fingerprint=report.fingerprint,
                        status="open",
                    )
                )

            search = outcome.plan.search
            if search is not None:
                session.add(
                    SearchMetric(
                        run_id=run.id,
                        algorithm=search.algorithm,
                        visited=search.visited,
                        expanded=search.expanded,
                        cost=search.cost,
                        path_length=search.path_length,
                        duration_ms=search.duration_ms,
                    )
                )
            for metric in outcome.plan.comparison:
                session.add(
                    SearchMetric(
                        run_id=run.id,
                        algorithm=metric.algorithm,
                        visited=metric.visited,
                        expanded=metric.expanded,
                        cost=metric.cost,
                        path_length=metric.path_length,
                        duration_ms=metric.duration_ms,
                    )
                )
            return run.id

    # ------------------------------------------------------------------ #
    # bug-injection control plane
    # ------------------------------------------------------------------ #
    async def _set_bugs(self, flags: Dict[str, bool]) -> None:
        """Toggle the target app's bug flags over HTTP."""
        try:
            import httpx

            async with httpx.AsyncClient(timeout=5.0) as client:
                for name, enabled in flags.items():
                    await client.post(
                        f"{self.base_url.rstrip('/')}/api/bugs",
                        json={"name": name, "enabled": enabled},
                    )
        except Exception as exc:  # noqa: BLE001 - target may be offline
            if self.verbose:
                print(f"[orchestrator] could not set bug flags: {exc}")

    async def get_bugs(self) -> Dict[str, Any]:
        try:
            import httpx

            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(f"{self.base_url.rstrip('/')}/api/bugs")
                return response.json()
        except Exception:  # noqa: BLE001
            return {"bugs": {}, "active": []}

    async def reset_target(self) -> None:
        try:
            import httpx

            async with httpx.AsyncClient(timeout=5.0) as client:
                await client.post(f"{self.base_url.rstrip('/')}/api/reset-state")
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------------ #
    # benchmarking: fixed script vs BrowserPilot
    # ------------------------------------------------------------------ #
    async def benchmark(
        self,
        goals: Optional[List[str]] = None,
        *,
        iterations: int = 1,
    ) -> Dict[str, Any]:
        """Compare a *fixed* Playwright script against the agent loop.

        The baseline uses hard-coded selectors (``#register-submit``,
        ``#login-submit`` …) that break the moment the DOM shifts — the
        exact scenario BrowserPilot is designed to survive.
        """
        goals = goals or [
            "Register a new user, log in and update the profile",
            "Reset the password and sign in with the new credentials",
        ]
        scenarios = [
            {"name": "clean", "bugs": {}},
            {"name": "selector_drift", "bugs": {"bug_3_selector_drift": True}},
            {"name": "silent_submit", "bugs": {"bug_1_disabled_submit": True}},
            {"name": "latency", "bugs": {"bug_4_latency": True}},
        ]

        rows: List[Dict[str, Any]] = []
        for scenario in scenarios:
            await self._set_bugs(scenario["bugs"])
            for goal in goals:
                for _ in range(iterations):
                    started = time.perf_counter()
                    agent_result = await self.run(goal, persist=True)
                    agent_ms = (time.perf_counter() - started) * 1000.0

                    baseline = await self._run_fixed_baseline(goal)
                    rows.append({
                        "scenario": scenario["name"],
                        "goal": goal,
                        "browserpilot": {
                            "completed": agent_result["summary"]["task_completion_rate"],
                            "bugs_found": agent_result["summary"]["bugs_found"],
                            "duration_ms": agent_ms,
                            "tokens": agent_result["summary"]["tokens_estimated"],
                        },
                        "fixed_script": baseline,
                    })
        await self._set_bugs({})
        return {"rows": rows, "metrics": _aggregate_benchmark(rows)}

    async def _run_fixed_baseline(self, goal: str) -> Dict[str, Any]:
        """Run the same flows with brittle, hard-coded selectors."""
        from playwright.async_api import async_playwright

        completed = 0.0
        total = 0
        error = ""
        started = time.perf_counter()
        try:
            async with async_playwright() as pw:
                browser = await pw.chromium.launch(headless=True)
                context = await browser.new_context()
                page = await context.new_page()
                base = self.base_url.rstrip("/")

                # --- fixed registration script (brittle selectors) -------- #
                if "register" in goal.lower() or "sign up" in goal.lower():
                    total += 1
                    await page.goto(f"{base}/register")
                    await page.fill("#email", "fixed@browserpilot.test")
                    await page.fill("#username", "fixed_user")
                    await page.fill("#password", "FixedPass123!")
                    await page.fill("#confirm", "FixedPass123!")
                    try:
                        await page.check("#terms")
                        await page.click("#register-submit")   # ← hard-coded id
                        await page.wait_for_url("**/profile", timeout=3000)
                        completed += 1
                    except Exception as exc:  # noqa: BLE001
                        error = str(exc).split("\n")[0][:200]

                # --- fixed login script ------------------------------------ #
                if "login" in goal.lower() or "sign in" in goal.lower():
                    total += 1
                    await page.goto(f"{base}/login")
                    await page.fill("#email", "demo@browserpilot.test")
                    await page.fill("#password", "Demo1234!")
                    try:
                        await page.click("#login-submit")      # ← hard-coded id
                        await page.wait_for_url("**/profile", timeout=3000)
                        completed += 1
                    except Exception as exc:  # noqa: BLE001
                        error = str(exc).split("\n")[0][:200]

                # --- fixed profile script ---------------------------------- #
                if "profile" in goal.lower():
                    total += 1
                    await page.goto(f"{base}/login")
                    await page.fill("#email", "demo@browserpilot.test")
                    await page.fill("#password", "Demo1234!")
                    try:
                        await page.click("#login-submit")
                        await page.wait_for_url("**/profile", timeout=3000)
                        await page.fill("#username", "fixed_user")
                        await page.click("#profile-save")      # ← hard-coded id
                        await page.wait_for_selector("#save-banner", timeout=3000)
                        completed += 1
                    except Exception as exc:  # noqa: BLE001
                        error = str(exc).split("\n")[0][:200]

                await browser.close()
        except Exception as exc:  # noqa: BLE001
            error = str(exc).split("\n")[0][:200]

        duration = (time.perf_counter() - started) * 1000.0
        return {
            "completed": (completed / total) if total else 0.0,
            "bugs_found": 0,          # a fixed script cannot classify defects
            "duration_ms": duration,
            "tokens": 0,              # no LLM context required
            "error": error,
        }


def _aggregate_benchmark(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Compute the headline benchmark metrics."""
    if not rows:
        return {}
    agent_rates = [r["browserpilot"]["completed"] for r in rows]
    fixed_rates = [r["fixed_script"]["completed"] for r in rows]
    agent_bugs = sum(r["browserpilot"]["bugs_found"] for r in rows)

    # Precision proxy: bug reports produced only on scenarios that inject a bug.
    injected = [r for r in rows if r["scenario"] != "clean"]
    clean = [r for r in rows if r["scenario"] == "clean"]
    true_positives = sum(
        r["browserpilot"]["bugs_found"] for r in injected
    )
    false_positives = sum(r["browserpilot"]["bugs_found"] for r in clean)
    precision = (
        true_positives / (true_positives + false_positives)
        if (true_positives + false_positives)
        else 1.0
    )
    false_alarm_rate = (
        false_positives / max(1, len(clean))
    )
    return {
        "task_completion_rate": {
            "browserpilot": round(sum(agent_rates) / len(agent_rates), 4),
            "fixed_script": round(sum(fixed_rates) / len(fixed_rates), 4),
        },
        "bug_detection_precision": round(precision, 4),
        "false_alarm_rate": round(false_alarm_rate, 4),
        "bugs_detected": agent_bugs,
        "avg_duration_ms": {
            "browserpilot": round(
                sum(r["browserpilot"]["duration_ms"] for r in rows) / len(rows), 2
            ),
            "fixed_script": round(
                sum(r["fixed_script"]["duration_ms"] for r in rows) / len(rows), 2
            ),
        },
        "avg_token_cost": round(
            sum(r["browserpilot"]["tokens"] for r in rows) / len(rows), 1
        ),
        "samples": len(rows),
    }
